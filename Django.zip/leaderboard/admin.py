from django.contrib import admin
from .models import LeaderBoard, Comment
# Register your models here.

admin.site.register(LeaderBoard)
admin.site.register(Comment)
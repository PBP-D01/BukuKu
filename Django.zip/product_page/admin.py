from django.contrib import admin
from product_page.models import Product

# Register your models here.
admin.site.register(Product)
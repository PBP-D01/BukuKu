from django.contrib import admin
from checkout.models import Checkout

# Register your models here.
admin.site.register(Checkout)